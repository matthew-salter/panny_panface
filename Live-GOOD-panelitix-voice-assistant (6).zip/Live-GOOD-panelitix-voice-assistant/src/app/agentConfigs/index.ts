import { AllAgentConfigsType } from "@/app/types";
import simpleExample from "./simpleExample";

export const allAgentSets: AllAgentConfigsType = {
  simpleExample,
};

export const defaultAgentSetKey = "simpleExample";